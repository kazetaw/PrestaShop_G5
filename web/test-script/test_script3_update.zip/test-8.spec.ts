import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('http://localhost:8080/en/');
  await page.getByRole('link', { name: 'Vocher 100' }).nth(2).click();
  await page.getByRole('button', { name: ' Add to cart' }).click();
  await page.getByRole('link', { name: ' Proceed to checkout' }).click();
  await page.getByRole('link', { name: 'Issue a tax invoice' }).click();
  await page.getByLabel('First name').click();
  await page.getByLabel('First name').fill('Suphawit');
  await page.getByLabel('Last name').click();
  await page.getByLabel('Last name').fill('Chamras');
  await page.getByLabel('Email').click();
  await page.getByLabel('Email').fill('suphawit.c@kkumail.com');
  await page.getByText(' Consent to the collection').click();
  await page.getByRole('button', { name: 'Continue' }).click();
});